//
//  File.swift
//  Exam1_55011212111
//
//  Created by student on 10/10/14.
//  Copyright (c) 2014 student. All rights reserved.
//

import Foundation
class File_2  {
    var total1:Double
    var volume:Double
    var price:Double{
    get{
        return volume * self.price
         }
    }
}